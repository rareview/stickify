/**
 * WordPress dependencies
 */
import apiFetch from '@wordpress/api-fetch';
import { compose } from '@wordpress/compose';
import { withSelect, withDispatch, useSelect } from '@wordpress/data';
import { PluginDocumentSettingPanel } from '@wordpress/edit-post';
import { useEffect, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
const RAREVIEW_SCHEDULED_STICKY_POSTS_META_KEY = '_rareview_scheduled_sticky_posts_sticky';
const RAREVIEW_SCHEDULED_STICKY_POSTS_UNTIL_META_KEY = '_rareview_scheduled_sticky_posts_sticky_until';
const RAREVIEW_SCHEDULED_STICKY_POSTS_START_META_KEY = '_rareview_scheduled_sticky_posts_sticky_start';

/**
 * Internal dependencies
 */
import MetaToggleControlInput from './MetaToggleControlInput';
import MetaDateControlInput from './MetaDateControlInput';

const RareviewScheduledStickyPostsSidebar = ( {
	postType,
	postMeta,
	setPostMeta,
	updateStickyState,
	coreSticky,
} ) => {
	const [ isLoading, setIsLoading ] = useState( true );
	const [ postTypes, setPostTypes ] = useState( [] );

	/**
	 * Fetch events from the REST API.
	 */
	useEffect( () => {
		const fetchRareviewScheduledStickyPosts = async () => {
			try {
				const response = await apiFetch( {
					path: '/rareview-scheduled-sticky-posts/v1/post-types',
				} );

				setPostTypes( response );
			} catch ( error ) {
				setPostTypes( [] );
			} finally {
				setIsLoading( false );
			}
		};

		fetchRareviewScheduledStickyPosts();
	}, [] );

	const supportsCustomFields = useSelect(
		( select ) => {
			const settings = select( 'core' ).getPostType( postType );
			return settings?.supports?.[ 'custom-fields' ] || false;
		},
		[ postType ]
	);

	if (
		! isLoading &&
		postTypes.length > 0 &&
		postTypes.includes( postType ) &&
		supportsCustomFields
	) {
		const isStickyEnabled =
			'post' === postType
				? Boolean( coreSticky ) ||
				  Boolean( postMeta?.[ RAREVIEW_SCHEDULED_STICKY_POSTS_META_KEY ] )
				: Boolean( postMeta?.[ RAREVIEW_SCHEDULED_STICKY_POSTS_META_KEY ] );

		return (
			<PluginDocumentSettingPanel
				title={ __( 'Scheduled Sticky Posts', 'rareview-scheduled-sticky-posts' ) }
				icon="edit"
				initialOpen="true"
			>
				<MetaToggleControlInput
					metaKey={ RAREVIEW_SCHEDULED_STICKY_POSTS_META_KEY }
					label={ __(
						'Move this post to the front of the archive?',
						'rareview-scheduled-sticky-posts'
					) }
					postType={ postType }
					postMeta={ postMeta }
					updateStickyState={ updateStickyState }
					coreSticky={ coreSticky }
				/>

				{ isStickyEnabled && (
					<>
						<MetaDateControlInput
							metaKey={ RAREVIEW_SCHEDULED_STICKY_POSTS_START_META_KEY }
							label={ __(
								'From when should this post be sticky? (optional)',
								'rareview-scheduled-sticky-posts'
							) }
							postMeta={ postMeta }
							setPostMeta={ setPostMeta }
						/>
						<MetaDateControlInput
							metaKey={ RAREVIEW_SCHEDULED_STICKY_POSTS_UNTIL_META_KEY }
							label={ __(
								'Until when should this post be sticky? (optional)',
								'rareview-scheduled-sticky-posts'
							) }
							postMeta={ postMeta }
							setPostMeta={ setPostMeta }
						/>
					</>
				) }
			</PluginDocumentSettingPanel>
		);
	}

	if (
		( ! isLoading && postTypes.length === 0 ) ||
		( ! isLoading &&
			postTypes.length > 0 &&
			! postTypes.includes( postType ) ) ||
		! supportsCustomFields
	) {
		return null;
	}
};

export default compose( [
	withSelect( ( select ) => {
		const postType = select( 'core/editor' ).getCurrentPostType();

		const returnAttributes = {
			postMeta: select( 'core/editor' ).getEditedPostAttribute( 'meta' ),
			postType,
			coreSticky: false,
		};

		if ( 'post' === postType ) {
			returnAttributes.coreSticky = Boolean(
				select( 'core/editor' ).getEditedPostAttribute( 'sticky' )
			);
		}

		return returnAttributes;
	} ),
	withDispatch( ( dispatch ) => {
		return {
			updateStickyState( postType, metaKey, value ) {
				const updates = {
					meta: {
						[ metaKey ]: value,
					},
				};

				if ( ! value ) {
					updates.meta[ RAREVIEW_SCHEDULED_STICKY_POSTS_START_META_KEY ] = undefined;
					updates.meta[ RAREVIEW_SCHEDULED_STICKY_POSTS_UNTIL_META_KEY ] = undefined;
				}

				if ( 'post' === postType ) {
					updates.sticky = value;
				}

				dispatch( 'core/editor' ).editPost( updates );
			},
			setPostMeta( newMeta ) {
				dispatch( 'core/editor' ).editPost( { meta: newMeta } );
			},
		};
	} ),
] )( RareviewScheduledStickyPostsSidebar );
