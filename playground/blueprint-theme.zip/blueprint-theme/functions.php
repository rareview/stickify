<?php
/**
 * Functions file for the Blueprint Theme.
 *
 * @package Stickify
 */

/**
 * Register custom post types.
 */
add_action(
	'init',
	function() {
		$recipe_labels = [
			'name'           => _x( 'Recipes', 'Post type general name', 'recipe' ),
			'singular_name'  => _x( 'Recipe', 'Post type singular name', 'recipe' ),
			'menu_name'      => _x( 'Recipes', 'Admin Menu text', 'recipe' ),
			'name_admin_bar' => _x( 'Recipe', 'Add New on Toolbar', 'recipe' ),
		];

		$recipe_args = [
			'labels'             => $recipe_labels,
			'description'        => 'Recipe custom post type.',
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'recipe' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 20,
			'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'custom-fields' ),
			'taxonomies'         => array( 'category', 'post_tag' ),
			'show_in_rest'       => true,
		];

		register_post_type( 'recipe', $recipe_args );

		$book_labels = [
			'name'           => _x( 'Books', 'Post type general name', 'book' ),
			'singular_name'  => _x( 'Book', 'Post type singular name', 'book' ),
			'menu_name'      => _x( 'Books', 'Admin Menu text', 'book' ),
			'name_admin_bar' => _x( 'Book', 'Add New on Toolbar', 'book' ),
		];

		$book_args = [
			'labels'             => $book_labels,
			'description'        => 'Book custom post type.',
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'book' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 20,
			'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'custom-fields' ),
			'taxonomies'         => array( 'category', 'post_tag' ),
			'show_in_rest'       => true
		];

		register_post_type( 'book', $book_args );
	}
);

/**
 * Enqueue parent theme styles.
 */
add_action(
	'wp_enqueue_scripts',
	function() {
		wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
	}
);
